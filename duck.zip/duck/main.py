import random
import struct
from functools import partial
from kivy.uix.screenmanager import ScreenManager
from kivy.core.image import Image as CoreImage
from kivy.uix.screenmanager import Screen
from kivy.properties import NumericProperty,BooleanProperty
from kivy.clock import Clock
from kivy.uix.image import Image
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.core.window import Window
from kivy.animation import Animation
from kivy.app import App
from kivy.properties import StringProperty



def get_alpha_value(pos, img):
    size = img.texture.size
    texture_ratio = img.texture.size[0] / float(img.texture.size[1])
    widget_ratio = img.size[0] / float(img.size[1])
    if texture_ratio >= widget_ratio:
        ratio = size[0]/float(img.size[0])
        x = pos[0] - img.x
        y = pos[1] - img.y - (img.size[1] - size[1] / ratio) / 2.0
        if y <= 0 or y >= size[1] / ratio:
            return (0, 0, 0, 0)
    else:
        ratio = size[1] / float(img.size[1])
        x = pos[0] - img.x - (img.size[0] - size[0] / ratio) / 2.0
        y = pos[1] - img.y
        if x <=0 or x >=size[0]/ratio:
            return (0,0,0,0)
    x = int(round(x * ratio))
    y = size[1] - 1 - int(round(y * ratio))
    offset = (x + y * size[0]) * 4
    return struct.unpack_from('4B', img.texture.pixels, offset)

class EnermyLayer(FloatLayout):

    def on_touch_down(self,touch):
        app = App.get_running_app()
        if app.root.current_screen.ammo_num:
            for child in self.children[:]:
                if child.dispatch('on_touch_down',touch):
                    return True

class FlyingScore(BoxLayout):
    n1 = StringProperty('0')
    n2 = StringProperty('0')

    def __init__(self,score,pos,**kwargs):
        super(FlyingScore,self).__init__(pos = pos,**kwargs)
        self.score = score
        s = str(self.score)
        self.n1 = s[0]
        self.n2 = s[1]


    def on_parent(self,widget,parent):
        if parent:
            ani = Animation(center_x=0.05*Window.size[0],center_y= 0.95*Window.size[1])
            app = App.get_running_app()
            ani.bind(on_complete = lambda x,y:self.parent.remove_widget(self))
            ani.bind(on_complete = partial(app.root.current_screen.update_player_score,self.score))
            ani.start(self)

class End(Popup):
    pass


class Pause(Popup):
    pass

class Quit(Popup):
    pass

class Bullet(Image):
    pass

class EBullet(Image):
    pass

class RTarget(Image):
    def on_parent(self,widget,parent):
        if parent:
            ani = Animation(pos_hint = {'center_y':random.uniform(0.6,0.65)})
            ani += Animation(pos_hint = {'center_y':0.5})
            ani.bind(on_complete = lambda x,y:self.parent.remove_widget(self))
            ani.start(self)

    def on_touch_down(self,touch):
        if self.collide_point(*touch.pos):
            if get_alpha_value(touch.pos,self) == (0,0,0,0):
                pass
            elif get_alpha_value(touch.pos,self) == (232,206,23,255):
                score = 17
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))
            elif get_alpha_value(touch.pos,self) == (187,128,68,255):
                score = 10
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))
            else:
                score = 13
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score,touch.pos))



class BTarget(Image):
    def on_parent(self,widget,parent):
        if parent:
            ani = Animation(pos_hint = {'center_y':random.uniform(0.5,0.55)})
            ani += Animation(pos_hint = {'center_y':0.4})
            ani.bind(on_complete = lambda x,y:self.parent.remove_widget(self))
            ani.start(self)

    def on_touch_down(self,touch):
        if self.collide_point(*touch.pos):
            if get_alpha_value(touch.pos,self) == (0,0,0,0):
                pass
            elif get_alpha_value(touch.pos,self) == (160,57,57,255):
                score = 16
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))
            elif get_alpha_value(touch.pos,self) == (166,201,203,255):
                score = 10
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))
            else:
                score = 12
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))




class BDuck(Image):
    def on_parent(self,widget,parent):
        if parent:
            ani = Animation(duration = 0)
            for i in range(10):
                ani += Animation(pos_hint = {'x':0.1*(i+1),'center_y':random.uniform(0.3,0.45)},duration = 0.5)
            ani.bind(on_complete = lambda x,y:self.parent.remove_widget(self))
            ani.start(self)


    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            if get_alpha_value(touch.pos, self) == (0, 0, 0, 0):
                pass
            elif get_alpha_value(touch.pos, self) in [(232,106,23,255),(255,255,255,255)]:
                score = 20
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))
            else:
                score = 10
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))

class WDuck(Image):
    def on_parent(self,widget,parent):
        if parent:
            ani = Animation(duration = 0)
            for i in range(10):
                ani += Animation(pos_hint = {'x':0.1*(i+1),'center_y':random.uniform(0.2,0.3)},duration = 0.4)
            ani.bind(on_complete = lambda x,y:self.parent.remove_widget(self))
            ani.start(self)


    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            if get_alpha_value(touch.pos, self) == (0, 0, 0, 0):
                pass
            elif get_alpha_value(touch.pos, self) in [(232,106,23,255),(255,255,255,255)]:
                score = 25
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))
            else:
                score = 10
                app = App.get_running_app()
                app.root.current_screen.hud.add_widget(FlyingScore(score, touch.pos))






class TitleScreen(Screen):
    bg_texture = CoreImage('bg_red.png').texture
    bg_texture.wrap = 'repeat'


class GameScreen(Screen):

    t = NumericProperty(0)
    ammo_num = NumericProperty(5)
    time = NumericProperty(60)
    player_score = NumericProperty(0)
    gameplay = BooleanProperty(False)

    bg_texture = CoreImage('bg_wood.png').texture
    bg_texture.wrap = 'repeat'
    w1_texture = CoreImage('water1.png').texture
    w1_texture.wrap = 'repeat'
    w2_texture = CoreImage('water2.png').texture
    w2_texture.wrap = 'repeat'
    g1_texture = CoreImage('grass1.png').texture
    g1_texture.wrap = 'repeat'
    g2_texture = CoreImage('grass2.png').texture
    g2_texture.wrap = 'repeat'
    c1_texture = CoreImage('curtain_top.png').texture
    c1_texture.wrap = 'repeat'
    c2_texture = CoreImage('curtain_straight.png').texture
    c2_texture.wrap = 'repeat'
    pause_icon = CoreImage('transparentLight12.png').texture

    def on_enter(self,*args):
        self.init()

    def on_leave(self, *args):
        self.stop_update()


    def init(self):
        self.pause = Pause()
        self.quit = Quit()
        self.end = End()
        self.max_ammo_num = 5
        self.ammo_num = 5
        self.time = 60
        self.player_score = 0
        Clock.schedule_once(self.on_ammo_num)
        self.init_curtain()
        self.start_game()
        self.gameplay = False


    def start_game(self):
        img = Image(source = 'text_ready.png',size_hint=(0.01,0.01),pos_hint = {'center_x':0.5,'center_y':0.5})
        ani = Animation(size_hint=(0.5,0.5),d=2)
        ani.bind(on_complete=lambda x, y: self.remove_widget(img))
        ani.bind(on_complete=self.move_curtain)
        self.add_widget(img)
        ani.start(img)

    def init_curtain(self):
        self.ids.right_curtain.pos_hint = {'top':0.9,'right':1}
        self.ids.left_curtain.pos_hint = {'top':0.9,'x':0}

    def move_curtain(self,*args):
        img = Image(source = 'text_go.png',size_hint=(0.01,0.01),pos_hint = {'center_x':0.5,'center_y':0.5})
        ani = Animation(size_hint=(0.5, 0.5),d =0.5)
        ani.bind(on_complete=lambda x, y: self.remove_widget(img))
        self.add_widget(img)
        ani.start(img)
        ani1 = Animation(pos_hint = {'top':0.9,'right':1.5})
        ani1.start(self.ids.right_curtain)
        ani2 = Animation(pos_hint = {'top':0.9,'x':-0.5})
        ani2.start(self.ids.left_curtain)
        ani2.bind(on_complete=self.update)
        self.gameplay = True


    def update(self,*args):
        Clock.schedule_interval(self.get_time, 1/60.0)
        Clock.schedule_interval(self.countdown_time, 1)
        Clock.schedule_interval(self.spawn, 1)

    def stop_update(self,*args):
        Clock.unschedule(self.get_time)
        Clock.unschedule(self.countdown_time)
        Clock.unschedule(self.spawn)


    def get_time(self,*args):
        self.t = Clock.get_boottime()


    def update_player_score(self,delta_score,*args):
        self.player_score += delta_score


    def countdown_time(self,*args):
        if self.time == 0:
            self.end_game()
        else:
            self.time -= 1


    def spawn(self,*args):
        seed = random.randint(1,4)
        if seed == 1:
            self.e_layer_1.add_widget(RTarget())
        elif seed == 2:
            self.e_layer_2.add_widget(BTarget())
        elif seed == 3:
            self.e_layer_3.add_widget(BDuck())
        else:
            self.e_layer_4.add_widget(WDuck())


    def on_touch_down(self,touch):
        self.ids.rifle.x = touch.pos[0]
        if self.gameplay:
            for child in self.children[:]:
                if child.dispatch('on_touch_down',touch):
                    return True
            if self.ammo_num > 0:
                self.ammo_num -= 1



    def on_ammo_num(self,*args):
        self.magazine.clear_widgets()
        for num in range(self.ammo_num):
            self.magazine.add_widget(Bullet())
        for num in range(self.max_ammo_num - self.ammo_num):
            self.magazine.add_widget(EBullet())

    def end_game(self,*args):
        self.stop_update()
        img = Image(source = 'text_timeup.png',size_hint=(0.01,0.01),pos_hint = {'center_x':0.5,'center_y':0.5})
        ani = Animation(size_hint=(0.5, 0.5),d =0.5)
        ani.bind(on_complete=lambda x, y: self.remove_widget(img))
        ani.bind(on_complete=self.end.open)
        self.add_widget(img)
        ani.start(img)


class MenuScreen(Screen):
    bg_texture1 = CoreImage('bg_red.png').texture
    bg_texture1.wrap = 'repeat'
    bg_texture2 = CoreImage('bg_blue.png').texture
    bg_texture2.wrap = 'repeat'
    bg_texture3 = CoreImage('bg_green.png').texture
    bg_texture3.wrap = 'repeat'


class ThxScreen(Screen):
    bg_texture = CoreImage('bg_green.png').texture
    bg_texture.wrap = 'repeat'

class ShopScreen(Screen):
    bg_texture = CoreImage('bg_blue.png').texture
    bg_texture.wrap = 'repeat'



# sm = ScreenManager()
# sm.add_widget(TitleScreen(name = 'TITLE'))
# sm.add_widget(GameScreen(name = 'GAME'))
# sm.add_widget(MenuScreen(name = 'MENU'))
# sm.add_widget(ThxScreen(name = 'THX'))
# sm.add_widget(ShopScreen(name = 'SHOP'))
# sm.current = 'TITLE'

class DuckShooting(App):
    pass
    # def build(self):
    #     return sm

if __name__ == '__main__':
    DuckShooting().run()